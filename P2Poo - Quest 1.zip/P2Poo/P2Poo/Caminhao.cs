﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2Poo
{
    class Caminhao : Veiculo
    {
        // Atributos
        private int eixos;

        // Métodos
        public Caminhao(string placa, int ano, int eixos) : base(placa, ano)
        {
            this.eixos = eixos;
        }

        public override double Alugar()
        {
            double diaria = 300 * eixos - (DateTime.Now.Year - ano) * 50;
            return diaria;
        }

        // Getters & Setters
        public int Eixos
        {
            get { return eixos; }
            set { eixos = value; }
        }
    }
}

