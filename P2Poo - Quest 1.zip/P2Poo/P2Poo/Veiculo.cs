﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2Poo
{
    abstract class Veiculo
    {
        // Atributos
        protected string placa;
        protected int ano;

        // Métodos
        protected Veiculo(string placa, int ano)
        {
            this.placa = placa;
            this.ano = ano;
        }

        public abstract double Alugar();

        // Getters & Setters
        public string Placa
        {
            get { return placa; }
            set { placa = value; }
        }

        public int Ano
        {
            get { return ano; }
            set { ano = value; }
        }
    }
}

