﻿using System;

namespace P2Poo
{
    class Onibus : Veiculo
    {
        // Atributos
        private int assentos;

        // Construtor
        public Onibus(string placa, int ano, int assentos) : base(placa, ano)
        {
            this.assentos = assentos;
        }

        // Método Alugar
        public override double Alugar()
        {
            double diaria = 30 * assentos - (DateTime.Now.Year - ano) * 70;
            return diaria;
        }

        // Getter & Setter para Assentos
        public int Assentos
        {
            get { return assentos; }
            set { assentos = value; }
        }
    }
}
