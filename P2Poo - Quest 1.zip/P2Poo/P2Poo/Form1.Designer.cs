﻿namespace P2Poo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioOnibus = new System.Windows.Forms.RadioButton();
            this.radioCaminhao = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.masktbPlaca = new System.Windows.Forms.MaskedTextBox();
            this.masktbAno = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.labelQuantidade = new System.Windows.Forms.Label();
            this.tbQuantidade = new System.Windows.Forms.TextBox();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.picboxVeiculo = new System.Windows.Forms.PictureBox();
            this.lvVeiculos = new System.Windows.Forms.ListView();
            this.Placa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Ano = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Assentos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Eixos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Diaria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.picboxVeiculo)).BeginInit();
            this.SuspendLayout();
            // 
            // radioOnibus
            // 
            this.radioOnibus.AutoSize = true;
            this.radioOnibus.Location = new System.Drawing.Point(75, 29);
            this.radioOnibus.Name = "radioOnibus";
            this.radioOnibus.Size = new System.Drawing.Size(70, 20);
            this.radioOnibus.TabIndex = 0;
            this.radioOnibus.TabStop = true;
            this.radioOnibus.Text = "Ônibus";
            this.radioOnibus.UseVisualStyleBackColor = true;
            this.radioOnibus.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MudarOnibus);
            // 
            // radioCaminhao
            // 
            this.radioCaminhao.AutoSize = true;
            this.radioCaminhao.Location = new System.Drawing.Point(224, 29);
            this.radioCaminhao.Name = "radioCaminhao";
            this.radioCaminhao.Size = new System.Drawing.Size(89, 20);
            this.radioCaminhao.TabIndex = 1;
            this.radioCaminhao.TabStop = true;
            this.radioCaminhao.Text = "Caminhão";
            this.radioCaminhao.UseVisualStyleBackColor = true;
            this.radioCaminhao.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MudarCaminhao);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Placa";
            // 
            // masktbPlaca
            // 
            this.masktbPlaca.Location = new System.Drawing.Point(120, 111);
            this.masktbPlaca.Mask = "aaa-aaaa";
            this.masktbPlaca.Name = "masktbPlaca";
            this.masktbPlaca.Size = new System.Drawing.Size(193, 22);
            this.masktbPlaca.TabIndex = 3;
            // 
            // masktbAno
            // 
            this.masktbAno.Location = new System.Drawing.Point(120, 139);
            this.masktbAno.Mask = "0000";
            this.masktbAno.Name = "masktbAno";
            this.masktbAno.Size = new System.Drawing.Size(193, 22);
            this.masktbAno.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ano";
            // 
            // labelQuantidade
            // 
            this.labelQuantidade.AutoSize = true;
            this.labelQuantidade.Location = new System.Drawing.Point(27, 170);
            this.labelQuantidade.Name = "labelQuantidade";
            this.labelQuantidade.Size = new System.Drawing.Size(87, 16);
            this.labelQuantidade.TabIndex = 6;
            this.labelQuantidade.Text = "Qtd Assentos";
            // 
            // tbQuantidade
            // 
            this.tbQuantidade.Location = new System.Drawing.Point(120, 168);
            this.tbQuantidade.Name = "tbQuantidade";
            this.tbQuantidade.Size = new System.Drawing.Size(193, 22);
            this.tbQuantidade.TabIndex = 7;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.Location = new System.Drawing.Point(39, 218);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(153, 48);
            this.btnCadastrar.TabIndex = 8;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = true;
            this.btnCadastrar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ECadastrarVeiculo);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(243, 218);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(153, 48);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ELimparDados);
            // 
            // picboxVeiculo
            // 
            this.picboxVeiculo.BackColor = System.Drawing.SystemColors.Control;
            this.picboxVeiculo.Image = global::P2Poo.Properties.Resources.onibus;
            this.picboxVeiculo.Location = new System.Drawing.Point(474, 29);
            this.picboxVeiculo.Name = "picboxVeiculo";
            this.picboxVeiculo.Size = new System.Drawing.Size(341, 237);
            this.picboxVeiculo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picboxVeiculo.TabIndex = 10;
            this.picboxVeiculo.TabStop = false;
            // 
            // lvVeiculos
            // 
            this.lvVeiculos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Placa,
            this.Ano,
            this.Assentos,
            this.Eixos,
            this.Diaria});
            this.lvVeiculos.HideSelection = false;
            this.lvVeiculos.Location = new System.Drawing.Point(39, 300);
            this.lvVeiculos.Name = "lvVeiculos";
            this.lvVeiculos.Size = new System.Drawing.Size(776, 202);
            this.lvVeiculos.TabIndex = 11;
            this.lvVeiculos.UseCompatibleStateImageBehavior = false;
            this.lvVeiculos.View = System.Windows.Forms.View.Details;
            // 
            // Placa
            // 
            this.Placa.Text = "Placa";
            this.Placa.Width = 100;
            // 
            // Ano
            // 
            this.Ano.Text = "Ano";
            this.Ano.Width = 80;
            // 
            // Assentos
            // 
            this.Assentos.Text = "Assentos";
            this.Assentos.Width = 80;
            // 
            // Eixos
            // 
            this.Eixos.Text = "Eixos";
            this.Eixos.Width = 80;
            // 
            // Diaria
            // 
            this.Diaria.Text = "Custo Diário";
            this.Diaria.Width = 150;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 561);
            this.Controls.Add(this.lvVeiculos);
            this.Controls.Add(this.picboxVeiculo);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCadastrar);
            this.Controls.Add(this.tbQuantidade);
            this.Controls.Add(this.labelQuantidade);
            this.Controls.Add(this.masktbAno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.masktbPlaca);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioCaminhao);
            this.Controls.Add(this.radioOnibus);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picboxVeiculo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioOnibus;
        private System.Windows.Forms.RadioButton radioCaminhao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox masktbPlaca;
        private System.Windows.Forms.MaskedTextBox masktbAno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelQuantidade;
        private System.Windows.Forms.TextBox tbQuantidade;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.PictureBox picboxVeiculo;
        private System.Windows.Forms.ListView lvVeiculos;
        private System.Windows.Forms.ColumnHeader Placa;
        private System.Windows.Forms.ColumnHeader Ano;
        private System.Windows.Forms.ColumnHeader Assentos;
        private System.Windows.Forms.ColumnHeader Eixos;
        private System.Windows.Forms.ColumnHeader Diaria;
    }
}

