﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P2Poo
{
    public partial class Form1 : Form
    {
        // Construtor
        public Form1()
        {
            InitializeComponent();

            radioOnibus.Checked = true;
            radioCaminhao.Checked = false;
            picboxVeiculo.Image = Properties.Resources.onibus;
        }

        // Manipulador de evento para cadastrar um veículo
        private void ECadastrarVeiculo(object sender, MouseEventArgs e)
        {
            // Verifica campos vazios
            if (Ha_CamposVazios())
            {
                MessageBox.Show("Todos os campos devem ser preenchidos...");
                return;
            }

            string[] data = new string[5];

            // Caminhão //
            if (radioCaminhao.Checked)
            {
                // Cria objeto Caminhão
                Caminhao veiculo = new Caminhao(masktbPlaca.Text, Convert.ToInt32(masktbAno.Text), Convert.ToInt32(tbQuantidade.Text));
                string preco = veiculo.Alugar().ToString("C2");

                // Preenche array de informações
                data[0] = veiculo.Placa;
                data[1] = Convert.ToString(veiculo.Ano);
                data[2] = "";
                data[3] = Convert.ToString(veiculo.Eixos);
                data[4] = Convert.ToString(preco);

                MessageBox.Show($"Aluguel: {preco}");
            }
            // Ônibus //
            else
            {
                // Cria objeto Ônibus
                Onibus veiculo = new Onibus(masktbPlaca.Text, Convert.ToInt32(masktbAno.Text), Convert.ToInt32(tbQuantidade.Text));
                string preco = veiculo.Alugar().ToString("C2");

                // Preenche array de informações
                data[0] = veiculo.Placa;
                data[1] = Convert.ToString(veiculo.Ano);
                data[2] = Convert.ToString(veiculo.Assentos);
                data[3] = "";
                data[4] = Convert.ToString(preco);

                MessageBox.Show($"Aluguel: {preco}");
            }

            // Adiciona item à ListView
            lvVeiculos.Items.Add(new ListViewItem(data));
            // Limpa campos de entrada
            LimparInputs();
        }

        // Manipulador de evento para limpar dados
        private void ELimparDados(object sender, MouseEventArgs e)
        {
            LimparInputs();
        }

        // Método para limpar campos de entrada
        private void LimparInputs()
        {
            masktbPlaca.Text = "";
            masktbAno.Text = "";
            tbQuantidade.Text = "";
        }

        // Método para verificar se há campos de entrada vazios
        private bool Ha_CamposVazios()
        {
            return (masktbPlaca.Text == "   -" || masktbAno.Text == "" || tbQuantidade.Text == "");
        }

        // Manipulador de evento para mudar para Ônibus
        private void MudarOnibus(object sender, MouseEventArgs e)
        {
            radioOnibus.Checked = true;
            radioCaminhao.Checked = false;

            picboxVeiculo.Image = Properties.Resources.onibus;
            labelQuantidade.Text = "Qtd Assentos";
        }

        // Manipulador de evento para mudar para Caminhão
        private void MudarCaminhao(object sender, MouseEventArgs e)
        {
            radioOnibus.Checked = false;
            radioCaminhao.Checked = true;

            picboxVeiculo.Image = Properties.Resources.caminhao;
            labelQuantidade.Text = "      Qtd Eixos";
        }
    }
}

