﻿using System;
using System.Collections.Generic;

public class PilhaDePecas
{
    // Declara uma pilha para armazenar os objetos do tipo Peca
    private Stack<Peca> pilha;

    // Construtor que inicializa a pilha
    public PilhaDePecas()
    {
        pilha = new Stack<Peca>();
    }

    // Método para empilhar (adicionar) uma nova peça na pilha
    public void Empilhar(Peca peca)
    {
        pilha.Push(peca);
    }

    // Método para desempilhar (remover) a peça do topo da pilha
    public Peca Desempilhar()
    {
        // Retorna a peça no topo ou null se a pilha estiver vazia
        return pilha.Count > 0 ? pilha.Pop() : null;
    }

    // Método para substituir uma peça específica por outra na pilha
    public void SubstituirPeca(string nomePecaVelha, string nomePecaNova)
    {
        // Cria uma pilha temporária para armazenar as peças enquanto procura a peça a ser substituída
        Stack<Peca> pecasTemp = new Stack<Peca>();

        // Percorre a pilha original até encontrar a peça velha ou esvaziar a pilha
        while (pilha.Count > 0)
        {
            // Remove a peça do topo da pilha
            Peca pecaAtual = Desempilhar();

            // Se a peça atual for a que precisa ser substituída, coloca a nova peça na pilha temporária
            if (pecaAtual.Nome == nomePecaVelha)
            {
                pecasTemp.Push(new Peca(nomePecaNova));
                break; // Para o loop após a substituição
            }
            else
            {
                // Se não for a peça procurada, empilha a peça atual na pilha temporária
                pecasTemp.Push(pecaAtual);
            }
        }

        // Reempilha todas as peças de volta na pilha original na ordem certa
        while (pecasTemp.Count > 0)
        {
            Empilhar(pecasTemp.Pop());
        }
    }

    // Método para exibir o estado atual da pilha
    public void MostrarPilha()
    {
        Console.WriteLine("Estado atual da pilha:");

        // Percorre e imprime cada peça na pilha
        foreach (var peca in pilha)
        {
            Console.WriteLine(peca);
        }
    }
}