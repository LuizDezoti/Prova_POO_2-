﻿public class Montador
{
    // Declara uma variável privada para armazenar a pilha de peças
    private PilhaDePecas pilhaDePecas;

    // Construtor da classe Montador que inicializa a pilha de peças
    public Montador()
    {
        // Cria uma nova instância de PilhaDePecas, onde as peças serão armazenadas
        pilhaDePecas = new PilhaDePecas();
    }

    // Método para montar o ventilador com algumas peças específicas
    public void MontarVentilador()
    {
        // Adiciona várias peças na pilha, simulando a montagem do ventilador
        pilhaDePecas.Empilhar(new Peca("Cúpula de Vidro"));
        pilhaDePecas.Empilhar(new Peca("Lâmpada"));
        pilhaDePecas.Empilhar(new Peca("Hélice Quebrada"));
        pilhaDePecas.Empilhar(new Peca("Suporte"));
    }

    // Método para substituir uma peça específica na pilha
    public void SubstituirPeca(string nomePecaVelha, string nomePecaNova)
    {
        // Chama o método SubstituirPeca na instância de PilhaDePecas, passando o nome da peça antiga e da nova
        pilhaDePecas.SubstituirPeca(nomePecaVelha, nomePecaNova);
    }

    // Método para exibir todas as peças da pilha
    public void ExibirPilha()
    {
        // Chama o método MostrarPilha na instância de PilhaDePecas para exibir as peças
        pilhaDePecas.MostrarPilha();
    }
}