﻿using System;

// Define a classe principal chamada Programa
class Programa
{
    // Método principal que é o ponto de entrada do programa
    static void Main(string[] args)
    {
        // Cria uma nova instância da classe Montador
        Montador montador = new Montador();

        // Chama o método para montar o ventilador (provavelmente vai empilhar algumas peças)
        montador.MontarVentilador();

        // Exibe a pilha de peças do ventilador montado
        Console.WriteLine("Pilha original:");
        montador.ExibirPilha();

        // Informa que vai substituir uma peça na pilha
        Console.WriteLine("\nSubstituindo a peça 'Hélice' por 'Hélice Nova'...");

        // Substitui a peça 'Hélice Quebrada' por 'Hélice Nova' na pilha de peças do montador
        montador.SubstituirPeca("Hélice Quebrada", "Hélice Nova");

        // Exibe a pilha de peças após a substituição
        Console.WriteLine("\nPilha após a substituição:");
        montador.ExibirPilha();
    }
}